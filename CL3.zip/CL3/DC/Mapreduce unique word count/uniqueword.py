from mrjob.job import MRJob  # Import base class for MRJob
from mrjob.step import MRStep  # Import MRStep to define multi-step jobs
import re  # Import regex module

# Regular expression to match words consisting of only letters (ignores numbers and symbols)
WORD_RE = re.compile(r'\b[a-zA-Z]+\b')

class MRUniqueWordCount(MRJob):  # Define a MapReduce job class

    # Mapper: Emits each unique word (per line) with a dummy value (None)
    def mapper(self, _, line):
        # Convert line to lowercase and extract unique words using a set
        for word in set(WORD_RE.findall(line.lower())):
            yield word, None  # Emit each unique word once per line

    # First reducer: For each unique word, emit a count of 1
    def reducer(self, word, _):
        yield "UniqueWordsCount", 1  # Emit a key with a value of 1 for each unique word

    # Second reducer: Sum all the 1s to get the total number of unique words
    def reducer_sum(self, key, values):
        yield key, sum(values)  # Emit the total unique word count

    # Define the sequence of steps for the job
    def steps(self):
        return [
            MRStep(mapper=self.mapper, reducer=self.reducer),        # Step 1: Extract and count unique words
            MRStep(reducer=self.reducer_sum)                         # Step 2: Sum all unique word counts
        ]

if __name__ == '__main__':
    MRUniqueWordCount.run()
