from mrjob.job import MRJob  # Import MRJob to create a MapReduce job
import re  # Import regex module for word extraction

# Regular expression to match words (alphanumeric and apostrophes)
WORD_REGEXP = re.compile(r"[\w']+")

# Define a MapReduce job class
class MRWordCount(MRJob):

    # Mapper function: takes each line and emits (word, 1) for every word found
    def mapper(self, _, line):
        # Use regex to find all words in the line
        for word in WORD_REGEXP.findall(line):
            # Emit each word in lowercase along with count 1
            yield word.lower(), 1

    # Reducer function: sums the counts for each unique word
    def reducer(self, word, counts):
        # Emit the word and the total count across all lines
        yield word, sum(counts)

if __name__ == '__main__':
    MRWordCount.run()  