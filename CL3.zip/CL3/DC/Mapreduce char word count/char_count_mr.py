from mrjob.job import MRJob  # Import the base class for writing MapReduce jobs

class MRCharCount(MRJob):  # Define a class that inherits from MRJob

    # Mapper function: processes each line of input
    def mapper(self, _, line):
        # Iterate through each character in the line (after stripping whitespace)
        for char in line.strip():
            # Emit the character as the key and 1 as the count
            yield char, 1

    # Reducer function: aggregates counts for each character
    def reducer(self, char, counts):
        # Sum all the counts for a given character
        yield char, sum(counts)

if __name__ == '__main__':
    MRCharCount.run()  
