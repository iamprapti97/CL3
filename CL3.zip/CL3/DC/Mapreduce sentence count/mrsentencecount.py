from mrjob.job import MRJob
import re

# Define sentence-ending punctuation
SENTENCE_ENDINGS = re.compile(r'[.?!]')

class MRSentenceCount(MRJob):

    OUTPUT_PROTOCOL = None  # Disable output formatting

    def mapper(self, _, line):
        sentences = SENTENCE_ENDINGS.findall(line)
        yield "Sentences", len(sentences)

    def reducer(self, key, values):
        total = sum(values)
        print(f"The number of sentences is {total}")

if __name__ == '__main__':
    MRSentenceCount.run()

