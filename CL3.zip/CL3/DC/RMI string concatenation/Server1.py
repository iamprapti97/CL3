import Pyro4  # Import Pyro4 module for creating and handling remote objects

# Expose the StringConcatenator class to be accessible remotely
@Pyro4.expose
class StringConcatenator:
    # Method to concatenate two strings
    def concatenate(self, str1, str2):
        return str1 + str2  # Returns the concatenated result of the two strings

# Create a Pyro4 Daemon to handle incoming client requests
daemon = Pyro4.Daemon()

# Register the StringConcatenator object with the Pyro4 Daemon
uri = daemon.register(StringConcatenator)

# Print the URI of the registered object, so clients can connect to it
print("Server URI:", uri)

# Start the daemon's request loop, which will keep the server running and accepting client requests
daemon.requestLoop()
