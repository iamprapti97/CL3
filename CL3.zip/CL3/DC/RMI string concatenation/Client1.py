import Pyro4  # Import Pyro4 module to interact with remote objects

# Ask the user to input the URI of the server where the Concatenator service is hosted
uri = input("Enter the URI of the server: ")

# Create a proxy object to communicate with the remote Concatenator service using the provided URI
concatenator = Pyro4.Proxy(uri)

# Ask the user to input the first string
str1 = input("Enter the first string: ")

# Ask the user to input the second string
str2 = input("Enter the second string: ")

# Call the remote 'concatenate' method on the Concatenator service through the proxy
result = concatenator.concatenate(str1, str2)

# Print the concatenated result returned by the server
print("Concatenated string:", result)
