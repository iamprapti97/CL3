import Pyro4  # Import Pyro4 module for remote object communication

# Ask the user for the server URI, which is the address where the Palindrome service is hosted
uri = input("Enter Server URI: ")

# Create a proxy object that will interact with the remote Palindrome service at the given URI
check = Pyro4.Proxy(uri)

# Ask the user for a string to check if it's a palindrome
s = input("Enter string to check: ")

# Call the remote method 'is_palindrome' on the server through the proxy object
result = check.is_palindrome(s)

# Print the result returned by the server: "yes" or "no"
print(result)

