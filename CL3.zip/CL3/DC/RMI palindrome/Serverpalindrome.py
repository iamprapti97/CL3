import Pyro4  # Import Pyro4 module for remote object communication

# Expose the class as a Pyro4 remote object
@Pyro4.expose
class Palindrome:
    # Method to check if a string is a palindrome
    def is_palindrome(self, s):
        # Check if the string is equal to its reverse
        if s == s[::-1]:
            return "yes"  # Return "yes" if it's a palindrome
        else:
            return "no"  # Return "no" if it's not a palindrome

# Create a Pyro4 Daemon (a server that listens for incoming requests)
daemon = Pyro4.Daemon()

# Register the Palindrome object with the daemon, so it can be accessed remotely
uri = daemon.register(Palindrome)

# Print the URI of the registered object for clients to connect to
print("Server URI: ", uri)

# Enter into the request loop, waiting for client requests
daemon.requestLoop()
