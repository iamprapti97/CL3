from xmlrpc.server import SimpleXMLRPCServer  # Import SimpleXMLRPCServer to create an XML-RPC server

# Function to calculate the factorial of a given number
def factorial(n):
    result = 1  # Start with result as 1
    for i in range(2, n + 1):  # Loop through numbers from 2 to n
        result *= i  # Multiply result by i at each step
    return str(result)  # Return the result as a string (as required in your code)

# Create the server, which will listen on localhost at port 8000
server = SimpleXMLRPCServer(("localhost", 8000))

# Print a message indicating that the server is ready to accept requests
print("Server is listening on port 8000...")

# Register the 'factorial' function with the server so clients can call it
server.register_function(factorial, "factorial")

# Keep the server running and waiting for incoming requests
server.serve_forever()
