import xmlrpc.client  # Import xmlrpc.client to communicate with an XML-RPC server

# Connect to the XML-RPC server running on localhost at port 8000
proxy = xmlrpc.client.ServerProxy("http://localhost:8000/")

# Take input from the user for the integer whose factorial is to be calculated
num = int(input("Enter an integer to calculate factorial: "))

# Call the remote 'factorial' function on the server through the proxy, passing the input number
result = proxy.factorial(num)

# Print the result of the factorial calculation
print(f"Factorial of {num} is {result}")
