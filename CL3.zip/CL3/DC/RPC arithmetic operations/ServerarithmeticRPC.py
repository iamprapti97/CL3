from xmlrpc.server import SimpleXMLRPCServer  # Import SimpleXMLRPCServer for creating an XML-RPC server

# Function to perform basic arithmetic operations
def calculate(num1, num2, operator):
    # Perform the operation based on the operator provided
    if operator == '+':
        return str(num1 + num2)  # Return the sum as a string
    elif operator == '-':
        return str(num1 - num2)  # Return the difference as a string
    elif operator == '*':
        return str(num1 * num2)  # Return the product as a string
    elif operator == '/':
        # Handle division, check for division by zero
        return str(num1 / num2) if num2 != 0 else "Error: Division by zero"
    else:
        return "Error: Unsupported Operation"  # If the operator is not recognized, return an error message

# Create an XML-RPC server that listens on localhost at port 8000
server = SimpleXMLRPCServer(("localhost", 8000))

# Register the 'calculate' function to be accessible through XML-RPC calls
server.register_function(calculate, "calculate")

# Print a message indicating the server is ready to accept requests
print("Server is ready to accept RPC Calls")

# Start the server and wait for incoming RPC requests
server.serve_forever()
