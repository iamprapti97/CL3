import xmlrpc.client  # Import the xmlrpc.client module to interact with XML-RPC servers

# Create a proxy object that connects to the XML-RPC server at the specified address (localhost:8000)
proxy = xmlrpc.client.ServerProxy("http://localhost:8000/")

# Prompt the user to input the first number (num1), converting the input to a float
num1 = float(input("Enter num1: "))

# Prompt the user to input the second number (num2), also converting the input to a float
num2 = float(input("Enter num2: "))

# Prompt the user to input the operator for the desired operation (+, -, *, /)
operator = input("Enter operation (+,-,*,/): ")

# Call the remote 'calculate' method on the server via the proxy, passing the numbers and operator
result = proxy.calculate(num1, num2, operator)

# Print the result returned by the server (the result of the calculation)
print(result)
